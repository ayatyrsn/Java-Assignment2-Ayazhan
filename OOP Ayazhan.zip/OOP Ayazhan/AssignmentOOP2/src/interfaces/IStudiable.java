package interfaces;

public interface IStudiable {
    void study();
    void takeExam();
}