package interfaces;

public interface IWorkable {
    void work();
    void takeBreak();
}